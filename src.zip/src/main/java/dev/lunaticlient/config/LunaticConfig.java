package dev.lunaticlient.config;

import com.google.gson.*;
import dev.lunaticlient.LunaticClient;
import net.fabricmc.loader.api.FabricLoader;
import java.io.*;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;

/**
 * JSON-backed config stored at .minecraft/config/lunatic-client.json
 * Persists module enabled/disabled states and settings automatically.
 */
public class LunaticConfig {

    private static final Path CONFIG_PATH = FabricLoader.getInstance()
        .getConfigDir().resolve("lunatic-client.json");

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private Map<String, Boolean> moduleStates = new HashMap<>();

    public void load() {
        try {
            if (CONFIG_PATH.toFile().exists()) {
                Reader r = new FileReader(CONFIG_PATH.toFile());
                JsonObject json = GSON.fromJson(r, JsonObject.class);
                r.close();
                if (json.has("modules")) {
                    json.getAsJsonObject("modules").entrySet().forEach(e ->
                        moduleStates.put(e.getKey(), e.getValue().getAsBoolean()));
                }
                // Restore states
                if (LunaticClient.moduleManager != null) {
                    moduleStates.forEach((name, enabled) -> {
                        var m = LunaticClient.moduleManager.getByName(name);
                        if (m != null) m.setEnabled(enabled);
                    });
                }
            }
        } catch (Exception e) {
            LunaticClient.LOGGER.warn("[Lunatic Config] Failed to load config: {}", e.getMessage());
        }
    }

    public static void save() {
        try {
            JsonObject json = new JsonObject();
            JsonObject modules = new JsonObject();
            if (LunaticClient.moduleManager != null) {
                LunaticClient.moduleManager.getAll().forEach(m ->
                    modules.addProperty(m.getName(), m.isEnabled()));
            }
            json.add("modules", modules);
            Writer w = new FileWriter(CONFIG_PATH.toFile());
            GSON.toJson(json, w);
            w.close();
        } catch (Exception e) {
            LunaticClient.LOGGER.warn("[Lunatic Config] Failed to save config: {}", e.getMessage());
        }
    }
}
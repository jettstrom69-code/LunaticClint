package dev.lunaticlient.cosmetics;

public class CosmeticManager {
    private boolean capeEnabled = true;

    public void init() {
        // Future: load cosmetic preferences from LunaticConfig
    }

    public boolean isCapeEnabled() { return capeEnabled; }
    public void setCapeEnabled(boolean v) { capeEnabled = v; }
}
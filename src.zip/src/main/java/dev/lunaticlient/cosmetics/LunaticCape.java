package dev.lunaticlient.cosmetics;

import dev.lunaticlient.LunaticClient;
import net.minecraft.client.render.entity.feature.CapeFeatureRenderer;
import net.minecraft.util.Identifier;

/**
 * Provides the identifier for the Lunatic Client branded cape texture.
 * Applied via PlayerEntityRendererMixin.
 */
public class LunaticCape {

    public static final Identifier CAPE_TEXTURE =
        Identifier.of(LunaticClient.MOD_ID, "textures/cape/lunatic_cape.png");

    public static boolean shouldRenderCape() {
        return true; // All Lunatic Client users get the cape
    }
}
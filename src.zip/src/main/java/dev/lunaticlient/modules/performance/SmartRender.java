package dev.lunaticlient.modules.performance;

import dev.lunaticlient.modules.Module;

public class SmartRender extends Module {
    public SmartRender() {
        super("Smart Render", "Auto-adjusts render distance.", "Performance");
    }
}
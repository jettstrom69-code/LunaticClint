package dev.lunaticlient.modules.performance;

import dev.lunaticlient.modules.Module;
import net.minecraft.client.MinecraftClient;

public class FpsBoost extends Module {

    private int prevParticles;

    public FpsBoost() {
        super("FPS Boost", "Disables expensive visual features to maximize FPS.", "Performance");
    }

    @Override
    public void onEnable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        prevParticles = mc.options.getParticles().getValue().getId();
        mc.options.getCloudRenderModeOption().setValue(net.minecraft.client.option.CloudRenderMode.OFF);
        mc.options.getParticles().setValue(net.minecraft.particle.ParticlesMode.MINIMAL);
        mc.options.getEntityShadows().setValue(false);
        mc.options.getGraphicsMode().setValue(net.minecraft.client.option.GraphicsMode.FAST);
    }

    @Override
    public void onDisable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        mc.options.getCloudRenderModeOption().setValue(net.minecraft.client.option.CloudRenderMode.FANCY);
        mc.options.getEntityShadows().setValue(true);
        mc.options.getGraphicsMode().setValue(net.minecraft.client.option.GraphicsMode.FANCY);
    }
}
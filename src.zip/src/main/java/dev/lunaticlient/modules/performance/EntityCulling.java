package dev.lunaticlient.modules.performance;

import dev.lunaticlient.modules.Module;

public class EntityCulling extends Module {
    public EntityCulling() {
        super("Entity Culling", "Skips rendering hidden entities.", "Performance");
    }
}
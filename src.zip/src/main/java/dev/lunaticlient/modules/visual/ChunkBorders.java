package dev.lunaticlient.modules.visual;

import dev.lunaticlient.modules.Module;

public class ChunkBorders extends Module {
    public ChunkBorders() {
        super("Chunk Borders", "Renders chunk boundary lines.", "Visual");
    }
}
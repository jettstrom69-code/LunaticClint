package dev.lunaticlient.modules.visual;

import dev.lunaticlient.modules.Module;

public class HitColor extends Module {
    public HitColor() {
        super("Hit Color", "Custom entity hit flash color.", "Visual");
    }
}
package dev.lunaticlient.modules.visual;

import dev.lunaticlient.modules.Module;

public class CustomSky extends Module {
    public CustomSky() {
        super("Custom Sky", "Replaces vanilla sky with Lunatic gradient.", "Visual");
    }
}
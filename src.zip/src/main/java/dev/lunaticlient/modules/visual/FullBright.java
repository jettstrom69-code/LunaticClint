package dev.lunaticlient.modules.visual;
     import dev.lunaticlient.modules.Module;
     import net.minecraft.client.MinecraftClient;
     public class FullBright extends Module {
         private float prevGamma;
         public FullBright() { super("Full Bright", "Removes darkness.", "Visual"); }
         @Override public void onEnable() {
             prevGamma = MinecraftClient.getInstance().options.getGamma().getValue().floatValue();
             MinecraftClient.getInstance().options.getGamma().setValue(10.0);
         }
         @Override public void onDisable() { MinecraftClient.getInstance().options.getGamma().setValue((double) prevGamma); }
     }
package dev.lunaticlient.gui.widgets;

import dev.lunaticlient.LunaticClient;
import dev.lunaticlient.modules.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.client.gui.screen.narration.NarrationMessageBuilder;
import net.minecraft.text.Text;

public class ModuleCard extends ClickableWidget {

    private final Module module;

    public ModuleCard(Module module, int x, int y, int width, int height) {
        super(x, y, width, height, Text.literal(module.getName()));
        this.module = module;
    }

    @Override
    protected void renderWidget(DrawContext ctx, int mouseX, int mouseY, float delta) {
        boolean on      = module.isEnabled();
        boolean hovered = this.isHovered();

        // Card background
        int bg = hovered ? 0xCC12002A : 0xCC0A0018;
        ctx.fill(getX(), getY(), getX() + getWidth(), getY() + getHeight(), bg);

        // Top accent line
        int accentColor = on ? LunaticClient.COLOR_SKY_BLUE : 0x44888888;
        ctx.fill(getX(), getY(), getX() + getWidth(), getY() + 2, accentColor);

        // Border
        ctx.drawBorder(getX(), getY(), getWidth(), getHeight(),
                       on ? LunaticClient.COLOR_PURPLE : 0x33FFFFFF);

        // Module name
        ctx.drawTextWithShadow(MinecraftClient.getInstance().textRenderer,
            module.getName(), getX() + 8, getY() + 8, on ? 0xFFFFFFFF : 0x88AAAAAA);

        // Toggle indicator
        String statusStr = on ? "●  ON" : "○  OFF";
        int statusColor  = on ? LunaticClient.COLOR_SKY_BLUE : 0x66888888;
        ctx.drawTextWithShadow(MinecraftClient.getInstance().textRenderer,
            statusStr, getX() + getWidth() - 50, getY() + 8, statusColor);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (!this.isHovered()) return false;
        if (button == 0) { module.toggle(); return true; }
        return false;
    }

    @Override
    protected void appendClickableNarrations(NarrationMessageBuilder b) { this.appendDefaultNarrations(b); }
}
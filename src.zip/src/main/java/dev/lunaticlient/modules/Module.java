package dev.lunaticlient.modules;

import dev.lunaticlient.config.LunaticConfig;

public abstract class Module {

    private final String name;
    private final String description;
    private final String category;
    private boolean enabled;
    private String keybind = "NONE";

    public Module(String name, String description, String category) {
        this.name        = name;
        this.description = description;
        this.category    = category;
        this.enabled     = false;
    }

    /** Called once when the module is first registered. */
    public void onInit() {}

    /** Called every render tick if enabled. */
    public void onRenderTick(float delta) {}

    /** Called every game tick if enabled. */
    public void onGameTick() {}

    /** Called when the module is toggled ON. */
    public void onEnable() {}

    /** Called when the module is toggled OFF. */
    public void onDisable() {}

    public void toggle() {
        enabled = !enabled;
        if (enabled) onEnable(); else onDisable();
        LunaticConfig.save(); // persist state
    }

    // Getters / setters
    public String getName()        { return name; }
    public String getDescription() { return description; }
    public String getCategory()    { return category; }
    public boolean isEnabled()     { return enabled; }
    public void setEnabled(boolean v) { this.enabled = v; }
    public String getKeybind()     { return keybind; }
    public void setKeybind(String k) { keybind = k; }
}
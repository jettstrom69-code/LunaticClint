package dev.lunaticlient.modules.utility;

import dev.lunaticlient.modules.Module;

public class NoHurtCam extends Module {
    public NoHurtCam() {
        super("No Hurt Cam", "Removes screen shake when taking damage.", "Utility");
    }
}
package dev.lunaticlient.modules.utility;

import dev.lunaticlient.modules.Module;
import net.minecraft.client.MinecraftClient;

public class AutoSprint extends Module {
    public AutoSprint() {
        super("Auto Sprint", "Automatically sprints without double-pressing W.", "Utility");
    }

    @Override
    public void onGameTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null && mc.options.forwardKey.isPressed()) {
            mc.player.setSprinting(true);
        }
    }
}
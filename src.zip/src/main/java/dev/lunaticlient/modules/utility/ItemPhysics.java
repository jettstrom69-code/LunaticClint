package dev.lunaticlient.modules.utility;

import dev.lunaticlient.modules.Module;

public class ItemPhysics extends Module {
    public ItemPhysics() {
        super("Item Physics", "Adds tumbling animation to items.", "Utility");
    }
}
package dev.lunaticlient.modules.utility;

import dev.lunaticlient.modules.Module;

public class BlockOverlay extends Module {
    public BlockOverlay() {
        super("Block Overlay", "Custom glowing block selection.", "Utility");
    }
}
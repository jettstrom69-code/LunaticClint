package dev.lunaticlient.gui.hud;

import dev.lunaticlient.LunaticClient;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

public class HudRenderer {
    private final MinecraftClient mc = MinecraftClient.getInstance();

    public void render(DrawContext ctx, float delta) {
        if (mc.player == null || mc.options.hudHidden) return;
        
        // FPS HUD example
        int fps = MinecraftClient.getCurrentFps();
        drawHudBox(ctx, "FPS", String.valueOf(fps), 4, 4);
    }

    public static void drawHudBox(DrawContext ctx, String label, String value, int x, int y) {
        int w = 50;
        ctx.fill(x, y, x + w, y + 22, LunaticClient.COLOR_BG_DARK);
        ctx.fill(x, y, x + w, y + 2, LunaticClient.COLOR_SKY_BLUE);
        ctx.drawTextWithShadow(MinecraftClient.getInstance().textRenderer, label, x + 4, y + 4, 0xAAAAAA);
        ctx.drawTextWithShadow(MinecraftClient.getInstance().textRenderer, value, x + 4, y + 13, 0xFFFFFF);
    }
}
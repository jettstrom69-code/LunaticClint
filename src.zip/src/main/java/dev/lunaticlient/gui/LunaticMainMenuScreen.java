package dev.lunaticlient.gui;

import dev.lunaticlient.LunaticClient;
import dev.lunaticlient.gui.background.AnimatedBackground;
import dev.lunaticlient.gui.widgets.LunaticButton;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;

public class LunaticMainMenuScreen extends Screen {

    private final AnimatedBackground background = new AnimatedBackground();

    public LunaticMainMenuScreen() { super(Text.literal("Lunatic Client")); }

    @Override
    protected void init() {
        background.init(this.width, this.height);
        int cx = this.width / 2;
        int by = this.height / 2 + 20;
        int bw = 200, bh = 24, gap = 30;

        addDrawableChild(new LunaticButton(cx - bw/2, by, bw, bh, Text.literal("Singleplayer"), btn -> this.client.setScreen(new net.minecraft.client.gui.screen.world.SelectWorldScreen(this))));
        addDrawableChild(new LunaticButton(cx - bw/2, by + gap, bw, bh, Text.literal("Multiplayer"), btn -> this.client.setScreen(new MultiplayerScreen(this))));
        addDrawableChild(new LunaticButton(cx - bw/2, by + gap*2, bw, bh, Text.literal("Mods"), btn -> this.client.setScreen(new LunaticModMenuScreen(this))));
        addDrawableChild(new LunaticButton(cx - bw/2, by + gap*3, bw, bh, Text.literal("Options"), btn -> this.client.setScreen(new OptionsScreen(this, this.client.options))));
        addDrawableChild(new LunaticButton(cx - bw/2, by + gap*4, bw, bh, Text.literal("Quit"), btn -> this.client.stop()));
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        background.render(ctx, this.width, this.height);
        ctx.drawCenteredTextWithShadow(this.textRenderer, Text.literal("LUNATIC CLIENT"), this.width/2, this.height/2 - 80, LunaticClient.COLOR_SKY_BLUE);
        super.render(ctx, mouseX, mouseY, delta);
    }
}
package dev.lunaticlient.gui;

import dev.lunaticlient.LunaticClient;
import dev.lunaticlient.gui.widgets.ModuleCard;
import dev.lunaticlient.modules.Module;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import java.util.ArrayList;
import java.util.List;

public class LunaticModMenuScreen extends Screen {

    private final Screen parent;

    public LunaticModMenuScreen(Screen parent) {
        super(Text.literal("Lunatic Client — Mods"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        List<Module> modules = LunaticClient.moduleManager.getAll();
        int startX = 50, startY = 50;
        for (int i = 0; i < modules.size(); i++) {
            addDrawableChild(new ModuleCard(modules.get(i), startX + (i % 3) * 230, startY + (i / 3) * 60, 220, 52));
        }
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ctx.fill(0, 0, this.width, this.height, 0xDD050510);
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("LUNATIC MODULES"), this.width / 2, 20, LunaticClient.COLOR_SKY_BLUE);
        super.render(ctx, mouseX, mouseY, delta);
    }

    @Override
    public void close() { this.client.setScreen(parent); }
}
package dev.lunaticlient;

import dev.lunaticlient.config.LunaticConfig;
import dev.lunaticlient.modules.ModuleManager;
import dev.lunaticlient.cosmetics.CosmeticManager;
import net.fabricmc.api.ClientModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LunaticClient implements ClientModInitializer {

    public static final String MOD_ID = "lunaticlient";
    public static final String NAME = "Lunatic Client";
    public static final String VERSION = "1.0.0";
    public static final Logger LOGGER = LoggerFactory.getLogger(NAME);

    // Sky Blue and Purple brand colors as packed ARGB ints
    public static final int COLOR_SKY_BLUE = 0xFF00BFFF;
    public static final int COLOR_PURPLE   = 0xFF7B2FBE;
    public static final int COLOR_BG_DARK  = 0xCC0A0A1A;

    private static LunaticClient instance;

    public static LunaticConfig config;
    public static ModuleManager moduleManager;
    public static CosmeticManager cosmeticManager;

    @Override
    public void onInitializeClient() {
        instance = this;
        LOGGER.info("[Lunatic Client] Initializing v{}", VERSION);

        config           = new LunaticConfig();
        moduleManager    = new ModuleManager();
        cosmeticManager  = new CosmeticManager();

        config.load();
        moduleManager.init();
        cosmeticManager.init();

        LOGGER.info("[Lunatic Client] Ready.");
    }

    public static LunaticClient getInstance() { return instance; }
}
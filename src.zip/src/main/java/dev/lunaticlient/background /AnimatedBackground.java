package dev.lunaticlient.gui.background;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.MathHelper;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class AnimatedBackground {

    private record Particle(float x, float y, float speed, float size, int color, float phase) {}
    private final List<Particle> particles = new ArrayList<>();
    private long startTime;

    public void init(int screenWidth, int screenHeight) {
        particles.clear();
        startTime = System.currentTimeMillis();
        Random rng = new Random();
        for (int i = 0; i < 80; i++) {
            float x = rng.nextFloat() * screenWidth;
            float y = rng.nextFloat() * screenHeight;
            float speed = 0.2f + rng.nextFloat() * 0.6f;
            float size = 2f + rng.nextFloat() * 5f;
            float phase = rng.nextFloat() * (float)(Math.PI * 2);
            int color = (i % 2 == 0) ? (0x55_00BFFF) : (0x55_7B2FBE);
            particles.add(new Particle(x, y, speed, size, color, phase));
        }
    }

    public void render(DrawContext ctx, int screenWidth, int screenHeight) {
        float elapsed = (System.currentTimeMillis() - startTime) / 1000f;
        ctx.fillGradient(0, 0, screenWidth, screenHeight, 0xFF050510, 0xFF0D0020);
        for (Particle p : particles) {
            float yPos = (p.y - elapsed * p.speed * 30f) % screenHeight;
            if (yPos < 0) yPos += screenHeight;
            float pulse = 0.7f + 0.3f * MathHelper.sin(elapsed * 1.5f + p.phase);
            int alpha = (int)(((p.color >> 24) & 0xFF) * pulse) & 0xFF;
            int color = (alpha << 24) | (p.color & 0x00FFFFFF);
            int r = (int)p.size;
            ctx.fill((int)(p.x - r), (int)(yPos - r), (int)(p.x + r), (int)(yPos + r), color);
        }
    }
}